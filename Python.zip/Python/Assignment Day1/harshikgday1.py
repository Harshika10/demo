# 1.Input your name into a variable called $name and then print "Hello,
#<your name here>".

name=input('ENTER NAME :')
print('Hello', name)



# 2.Write a program that adds two numbers and then prints out whether the
#sum of those two numbers is positive or negative.

x=int(input('enter the first number'))
y=int(input('enter the second number'))
z=x+y
if z>0 :
    print('Number is positive')
else :
    print('Number is negative')



# 3.Write a program that stores a number and keeps trying to get user input
#until the user enters the number correctly. As soon as the correct number
#is entered, it prints: Correct!

num=10;
a=int(input('Enter Number'))
while  a!=num :
    a=int(input('Enter Number'))
print('Correct')


# 4.Input your first name and last name as two separate variables, labeled
#as $firstname and $lastname respectively. Concatenate them together using
#the dot operator '.' into a new variable called $wholename. Then print out
#the $wholename.

firstname=input('enter the first name :')
lastname=input('enter the last name :')
wholename= firstname + "." + lastname
print(wholename)


# 5.Write a program to accept an input string from the user and toggle the
#character cases.

a=input("enter the string")
output= a.swapcase()
print(output)

# 6.Write a program which will perform sum and  multiplication  ,that sums and
#multiplies (respectively) all the numbers in a list of numbers. For example,
#sum([1, 2, 3, 4]) should return 10, and multiply([1, 2, 3, 4]) should return 24.

list=[1,2,3,4]
output=sum(list)
print(output)
c=1
for i in list:
    c=c*i
print(c)

# 7.Write a program that takes a value (i.e. a number, string, etc) x and a
#list of values a, and returns True if x is a member of a, False otherwise.
#(Note that this is exactly what the in operator does, but for the sake of the
#exercise you should pretend Python did not have this operator.)

n=int(input('enter the elements of list'))
l=[]
for i in range(0,n) :
    l.append(input(''))
a=input('enter the number to be searched')    
f=0
for i in l :
    if (i==a):
        print('True')
        f=1
        break
if f==0 :
    print('False')


# 8.Write a program that has two lists and print True if they have at least
#one member in common, False otherwise. You may use your is_member() function,
#or the in operator, but for the sake of the exercise, you should (also)
#write it using two nested for-loops.

n=int(input('enter the element'))
li1=[]
for i in range(0,n):
    li1.append(input(''))
m=int(input('enter the element'))
li2=[]
for i in range (0,m) :
    li2.append(input(''))
f=0
for i in li1 :
    for j in li2 :
        if(i==j) :
            print('True')
            f=1
            break
if f==0 :
    print('False')


# 9.Write a program for  histogram that takes a list of integers and prints
#a histogram to the screen. For example, histogram([4, 9, 7]) should
#print the following: 
#**** 
#********* 
#*******

l=[4,7,9]
for i in l:
    for j in range(0,i):
        print("*",end="")
    print("\n")
