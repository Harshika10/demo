"""
######## 1
def add(n1,n2):
    res = n1+n2
    return res
n1 = int(input("Enter first number: "))
n2 = int(input("Enter second number: "))
res = add(n1,n2)
#res = add(10,203,405,03,56,6)
#res = add(10,203,405,03,56)
#res = add(10,203,405)
print("Addition of {0} and {1} is {2}".format(n1,n2,res))


######## 2
def add1(*params):
   a = sum(params)
   print(a)

add1(10,203,405,3,56,6)
add1(10,203,405,3,56)
add1 (10,203,405)
    
####### 3

#(id, name, age)
#(id, age)
#(name, id, age)
#(age, name, id)
#(age, anme,id)

def getEmpDetails(id, age, name='Unknown'):
    print("I'm {1}, My EmpId is {0}, I'm {2} years old".format(id,name,age))

getEmpDetails(12345, 31)
getEmpDetails(12345, 31, name= 'Harshi')

"""
#######  4
def getEmpDetails(**details):
    print(type(details))
    print("I'm {1}, My EmpId is {0}\n I'm {2} years old".format(details.get('id'),details.get('name',details.get('age')))

getEmpDetails(id=13345,name='harshi', age=31) 


