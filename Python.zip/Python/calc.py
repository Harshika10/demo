def add(n1,n2)
    return n1+n2

def sub(n1,n2)
    return n1-n2

def mul(n1,n2)
    return n1*n2
