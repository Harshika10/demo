#1. Define a function generate_n_chars() that takes an integer n and a character
#c and returns a string, n characters long, consisting only of c:s.
#For example, generate_n_chars(5,"x") should return the string "xxxxx".
#(Python is unusual in that you can actually write an expression 5 * "x" that
#will evaluate to "xxxxx". For the sake of the exercise you should ignore that
#the problem can be solved in this manner.)

def generate_n_function(n,x):
    res=""
    for i in range(0,n):
        res=res+x
        
    return res;

n = int(input("Enter no of times: "))
x = str(input("Enter a character: "))

c = generate_n_function(n,x)
print("The string will be:", c)


#2. The function max() from exercise 1) and the function max_of_three() from
#exercise 2) will only work for two and three numbers, respectively. But
#suppose we have a much larger number of numbers, or suppose we cannot tell in
#advance how many they are? Write a function max_in_list() that takes a list
#of numbers and returns the largest one.

def max_in_list(a):
    largest = a[0];
    for i in a:
        if largest<i:
            largest = i
    print("Largest is: ", largest)

a=[];
lim = int(input("Enter Limit: "))
for i in range(0,lim):
    elem = input("")
    a.append(int(elem))

max_in_list(a)


# 3.Write a program that maps a list of words into a list of integers
#representing the lengths of the correponding words.

n=int(input("No. of words :"))
print ("Enter")
li=[]
for i in range(n):
    li.append(input())
di={}
for s in li:
    di[s]=len(s)
print(di)

# 4.Write a function find_longest_word() that takes a list of words and
#returns the length of the longest one. Modify the same to do with lambda
#expression.

n=int(input("How many words :"))
li=[]
for i in range(n):
    li.append(len(input()))
find_longest_word=lambda li:max(li)
print(find_longest_word(li))

#5.Write a function filter_long_words() that takes a list of words and an
#integer n and returns the list of words that are longer than n.
#Modify the same to do with lambda expression.

n=int(input("How many words"))
print ("Enter")
li=[]
for i in range(n):
    li.append(input())
num=int(input("Enter the value"))
def filter_longer_words(li):
    l2=[]
    for x in li:
        if len(x)>num:
            do=lambda x:l2.append(x)
            do(x)
    return l2
list1=filter_longer_words(li)
print (list1)


#6.Write a version of a palindrome recognizer that also accepts phrase
#such as "Go hang a salami I'm a lasagna hog.", "Was it a rat I saw?", "Step
#on no pets", "Sit on a potato pan, Otis", "Lisa Bonet ate no basil", "Satan,
#oscillate my metallic sonatas", "I roamed under it as a tired nude Maori",
#"Rise to vote sir", or the exclamation "Dammit, I'm mad!". Note that
#punctuation, capitalization, and spacing are usually ignored.

import re
st=input("Enter a string :")
st=re.sub(r"[^\w\s]","",st)
st=st.replace(" ","")
st=st.lower()
flag=1
l=len(st)
for i in range(l//2):
    if(st[i]!=st[l-1]):
        flag=0
        break
    l=l-1
if flag==1:
    print ("Palindrome")
else:
    print ("Not Palindrome")



#7.A pangram is a sentence that contains all the letters of the English
#alphabet at least once, for example: The quick brown fox jumps over the
#lazy dog. Your task here is to write a function to check a sentence to see
#if it is a pangram or not. 

import re
st=input("Enter a string :")
for i in range(10):
    st=st.replace(str(i),"")
st=re.sub(r"[^\w\s]","",st)
st=st.replace(" ","")
st=st.replace("[~`!@#$%^&*()_-+=]","")
st=st.lower()
word_set=set()
for i in st:
    word_set.add(i)
if len(word_set)==26:
    print ("Pangram")
else:
    print ("Not Pangram")



#8.Represent a small bilingual lexicon as a Python dictionary in the following
#fashion {"merry":"god", "christmas":"jul", "and":"och", "happy":gott",
#"new":"nytt", "year":"år"} and use it to translate your Christmas cards from
#English into Swedish. That is, write a function translate() that takes a list
#of English words and returns a list of Swedish words. 

def translate(st):
    words=st.split(" ")
    n=len(words)
    li=[]
    for i in range(n):
        try:
            li.append(dnry[words[i]])
        except:
            li.append(words[i])
    return li

dnry={"merry":"god","christmas":"jul","and":"och","happy":"gott","new":"nytt","year":"ar"}
st=input("Enter an English sentence : ")
li=translate(st)
print (li)


#9.Write a function char_freq() that takes a string and builds a frequency
#listing of the characters contained in it. Represent the frequency listing as
#a Python dictionary. Try it with something likechar_freq
#("abbabcbdbabdbdbabababcbcbab"). 

st=input("Enter a String : ")
di={}
for i in st:
    try:
        di[i]=di.get(i)+1
    except:
        di[i]=int(1)
print (di)


#10.Create a module called mathematics.py and provide subroutines (should be
#defined generally and should work for any number of arguments)

from mathematics import *
l1=[1,2,3]
l2=[4,5,7,6]
la=Add(l1,l2)
ls=Sub(l1,l2)
lso1=Sort_the_values(la)
lso2=Sort_the_values(ls)
lm1=Max(lso1)
lm2=Max(lso2)
print (la,ls,lso1,lso2,lm1,lm2)

#11. Try above programe with package.

import Ravi.mathematics

l1=[1,2,3,4]
l2=[5,6,7,8,9,10]
la=Ravi.mathematics.Add(l1,l2)
ls=Ravi.mathematics.Sub(l1,l2)
lso1=Ravi.mathematics.Sort_the_values(la)
lso2=Ravi.mathematics.Sort_the_values(ls)
lm1=Ravi.mathematics.Max(lso1)
lm2=Ravi.mathematics.Max(lso2)
print (la,ls,lso1,lso2,lm1,lm2)


#12. Create a Date class, which represents the Date with its attributes.
#Write a  UseDate class, which makes use of the Date class to instantiate,
#and call methods on the object. 

import Date
from datetime import date
class UserDate:
    today=date.today()
    d=Date.Date(today.day,today.month,today.year)
    d.printDate()


#13. WAP to read data from one file and writes in second file.

f=open("Ravindra1.txt","r")
data=f.read()
print("Read")
f=open("ravi.txt","w")
f.write(data)
f.close()
print("Write")


#14. WAP which will display diffrenent function of math and numpy library.

from math import *

print("Math:\n\nFactorial(100) :{0}\nSquare Root(9801): {1}\nSin(90) : {2}".format(factorial(100),sqrt(9801),sin(90)))

