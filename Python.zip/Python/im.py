import calc
    print(calc.add(10,20))
    
